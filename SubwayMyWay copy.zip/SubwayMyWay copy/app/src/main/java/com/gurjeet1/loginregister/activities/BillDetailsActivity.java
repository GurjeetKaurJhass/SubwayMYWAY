package com.gurjeet1.loginregister.activities;

import android.content.Intent;
import android.support.design.widget.Snackbar;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.gurjeet1.loginregister.R;
import com.gurjeet1.loginregister.model.Sandwich;
import com.gurjeet1.loginregister.model.User;
import com.gurjeet1.loginregister.sql.DatabaseHelper;

import java.awt.font.TextAttribute;

public class BillDetailsActivity extends AppCompatActivity {

    private TextView lblsandwichtype;
    private TextView lblsandwichsize;
    private TextView lblbreadtype;
    private TextView lblextracheese;
    private TextView lblextrameat;
    private TextView lblTotal;
    private TextView lblTax;
    private TextView lblTotalAmount;
    private Button btncancel;
    private Button btnconfirm;
    private double tax=0.13;
    Sandwich sandwich;
    private DatabaseHelper databaseHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_billdetails);

        lblsandwichtype = (TextView) findViewById(R.id.lblSandwichtype);
        lblsandwichsize = (TextView) findViewById(R.id.lblbreadsize);
        lblbreadtype = (TextView) findViewById(R.id.lblflavour);
        lblextracheese = (TextView) findViewById(R.id.lblcheese);
        lblextrameat = (TextView) findViewById(R.id.lblmeat);
        lblTotal=(TextView)findViewById(R.id.lblTotal);
        lblTax=(TextView)findViewById(R.id.lbltax);
        lblTotalAmount=(TextView) findViewById(R.id.lblamount);
        btncancel = (Button) findViewById(R.id.btncancel);
        btnconfirm = (Button)findViewById(R.id.btnconfirm);

        Intent mIntent = getIntent();
        Bundle mBundle = mIntent.getExtras();
        sandwich = (Sandwich) mBundle.getSerializable("sandwich");
//        Log.d("valueon bill",sandwich.getExtracheese().toString());
        Log.d("valueon bill",sandwich.getExtrameat().toString());
        Log.d("valueon bill",sandwich.getSandwichtype());
        Log.d("valueon bill",sandwich.getSize());


        lblsandwichtype.setText(sandwich.getSandwichtype());
        lblsandwichsize.setText(sandwich.getSize());
        lblbreadtype.setText(sandwich.getBreadtype());
        lblextracheese.setText(String.valueOf( sandwich.getExtracheese()));
        lblextrameat.setText(String.valueOf(sandwich.getExtrameat().toString()));
        lblTotal.setText(String.valueOf(sandwich.getPrice()));

        Double tax1=tax*(sandwich.getPrice());
        lblTax.setText(String.valueOf(tax1));
        lblTotalAmount.setText(String.valueOf(tax1+sandwich.getPrice())+sandwich.getExtracheese()+sandwich.getExtrameat());


        btnconfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseHelper = new DatabaseHelper(getApplicationContext());

                databaseHelper.addOrder(sandwich);
                Toast.makeText(getApplicationContext(), "Your order is placed", Toast.LENGTH_SHORT).show();


            }
        });

        btncancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(getApplicationContext(), "", Toast.LENGTH_SHORT).show();


                Intent intent1 = new Intent(BillDetailsActivity.this, LoginActivity.class);
                startActivity(intent1);


            }
        });


    }

}
