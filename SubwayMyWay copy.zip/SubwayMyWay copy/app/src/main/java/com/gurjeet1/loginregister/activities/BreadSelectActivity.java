package com.gurjeet1.loginregister.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;

import com.gurjeet1.loginregister.R;
import com.gurjeet1.loginregister.model.Sandwich;

public class BreadSelectActivity extends AppCompatActivity {
private RadioGroup rgbread;
private RadioGroup rgsize;
private Button btnAdd;
    Sandwich sandwich ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_breadselect);
        final Intent mIntent = getIntent();
        Bundle mBundle = mIntent.getExtras();
         sandwich = (Sandwich) mBundle.getSerializable("sandwich");



        Log.d("value12",sandwich.getSandwichtype());
        Log.d("value12",sandwich.getPrice().toString());

        rgbread=(RadioGroup) findViewById(R.id.rgbread);
        rgsize=(RadioGroup)findViewById(R.id.rgsize);
        btnAdd=(Button)findViewById(R.id.btnadd);


        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (rgbread.getCheckedRadioButtonId()) {
                    case R.id.rdItalian:
                        sandwich.setBreadtype("Italian");
                        break;
                    case R.id.rdherbs:
                        sandwich.setBreadtype("HerbsCheese");
                        break;
                    case R.id.rdhoney:
                        sandwich.setBreadtype("HoneyOats");
                        break;
                    case R.id.rdwholegrain:
                        sandwich.setBreadtype("Wholegrain");
                        break;
                }


                switch (rgsize.getCheckedRadioButtonId()) {
                    case R.id.rdsix:
                        sandwich.setSize("six inch");
                        break;

                    case R.id.rdfoot:
                        sandwich.setSize("footlong");
                        break;

                }


                Intent mIntent = new Intent(BreadSelectActivity.this, VeggieToppingsActivity.class);
                mIntent.putExtra("sandwich", sandwich);

                Log.d("value123",sandwich.getBreadtype());
                Log.d("value123",sandwich.getSize());
                startActivity(mIntent);
                finish();

            }
        });

        }


}
