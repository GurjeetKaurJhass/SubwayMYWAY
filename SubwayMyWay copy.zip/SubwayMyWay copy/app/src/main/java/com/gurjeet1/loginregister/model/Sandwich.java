package com.gurjeet1.loginregister.model;

import java.io.Serializable;

public class Sandwich implements Serializable {
    private String sandwichtype;
    private String breadtype;
    private String size;
    private String Ingredients;
    private double extracheese;
    private Double extrameat;
    private Double price;

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getSandwichtype() {
        return sandwichtype;
    }

    public void setSandwichtype(String sandwichtype) {
        this.sandwichtype = sandwichtype;
    }

    public String getBreadtype() {
        return breadtype;
    }

    public void setBreadtype(String breadtype) {
        this.breadtype = breadtype;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getIngredients() {
        return Ingredients;
    }

    public void setIngredients(String ingredients) {
        Ingredients = ingredients;
    }

    public double getExtracheese() {
        return extracheese;
    }

    public void setExtracheese(double extracheese) {
        this.extracheese = extracheese;
    }


    public Double getExtrameat() {
        return extrameat;
    }

    public void setExtrameat(Double extrameat) {
        this.extrameat = extrameat;
    }

    public void setExtra_cheese(double string) {
    }

    public void setTotalPrice(String string) {
    }
}
