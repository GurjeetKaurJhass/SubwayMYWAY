package com.gurjeet1.loginregister.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

import com.gurjeet1.loginregister.R;
import com.gurjeet1.loginregister.model.Sandwich;

public class ExtraActivity extends AppCompatActivity  {
    private Button btnadd;
    private CheckBox chkcheese;
    private CheckBox chkmeat;
    Sandwich sandwich;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_extra);

        final Intent mIntent = getIntent();
        Bundle mBundle = mIntent.getExtras();
        sandwich = (Sandwich) mBundle.getSerializable("sandwich");

        Log.d("valueon extra",sandwich.getIngredients());
        chkcheese = (CheckBox) findViewById(R.id.chkcheese);
        chkmeat = (CheckBox) findViewById(R.id.chkmeat);
        btnadd = (Button) findViewById(R.id.btnadd);
//        final Sandwich sandwich = new Sandwich();
        btnadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (chkcheese.isChecked()) {
                    sandwich.setExtracheese(1.00);

                } else {
                    sandwich.setExtracheese(0.0);
                }

                if (chkmeat.isChecked()) {
                    sandwich.setExtrameat(3.00);
                } else {
                    sandwich.setExtrameat(0.0);
                }
                Intent mIntent = new Intent(ExtraActivity.this, BillDetailsActivity.class);
                mIntent.putExtra("sandwich", sandwich);
//                Log.d("valueon extra",sandwich.getExtracheese().toString());
//                Log.d("valueon extra",sandwich.getExtrameat().toString());
                startActivity(mIntent);
                finish();

            }
        });




    }


}
