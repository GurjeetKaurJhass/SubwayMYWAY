package com.gurjeet1.loginregister.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;

import com.gurjeet1.loginregister.R;

public class ElectricityBillActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText edtCustomerId;
    private EditText edtCustomerName;
    private EditText edtEmail;
    private RadioGroup rgGender;
    private EditText edtUnitConsumed;

    private Button btnCalculate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_electricity_bill);

        edtCustomerId = (EditText) findViewById(R.id.edtId);
        edtCustomerName = (EditText) findViewById(R.id.edtName);
        edtEmail = (EditText) findViewById(R.id.edtEmail);
        rgGender = (RadioGroup) findViewById(R.id.rdGender);
        edtUnitConsumed = (EditText) findViewById(R.id.edtUnitConsumed);
        btnCalculate = (Button) findViewById(R.id.btnCalculate);
        btnCalculate.setOnClickListener(this);

        }

    public void onClick(View v) {
        CharSequence txtCustomerID = edtCustomerId.getText();
        if (TextUtils.isEmpty(txtCustomerID) || txtCustomerID.toString().length() == 0)

        {
            edtCustomerId.setError("Please Enter Customer Id");
        } else {
            edtCustomerId.setError(null);
        }


        String gender = "";


        switch (rgGender.getCheckedRadioButtonId()) {
            case R.id.rdMale:
                gender = "Male";
                break;
            case R.id.rdFemale:
                gender = "FeMale";
                break;
            case R.id.rdOther:
                gender = "Other";
                break;
        }

       double unitConsumed =Double.parseDouble(edtUnitConsumed.getText().toString());
        double totalAmount=0;

        Log.d("unit============", String.valueOf(unitConsumed));

        if(unitConsumed <= 100) {
            totalAmount= unitConsumed * 0.75;
        } else if(unitConsumed <= 250) {
            totalAmount= 75 + ((unitConsumed - 100) * 1.25);
        } else if(unitConsumed <= 450) {
            totalAmount= 262.5 + ((unitConsumed - 250) * 1.75);
        } else {
            totalAmount = 612.5 + ((unitConsumed - 450) * 2.25);
        }



        ElectricityBill electricityBill = new ElectricityBill(
                new Integer(String.valueOf(edtCustomerId.getText())),
                String.valueOf(edtCustomerName.getText()),
                String.valueOf(edtEmail.getText()),
                gender,
                new Integer(String.valueOf(edtUnitConsumed.getText())),
                        totalAmount
                        );



        Intent mIntent = new Intent(ElectricityBillActivity.this, BillDetailsActivity.class);
        mIntent.putExtra("electricityBill", electricityBill);
        startActivity(mIntent);
        finish();

    }
}

