package com.gurjeet1.loginregister.activities;

import java.io.Serializable;

public class ElectricityBill implements Serializable {



    private Integer customerId;
    private String customerName;
    private String email;
    private String gender;
    private Integer unitsConsumed;
    private Double TotalAmount;


    public ElectricityBill(Integer customerId, String customerName, String email, String gender,Integer unitsConsumed,Double TotalAmount) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.email = email;
        this.gender = gender;
        this.unitsConsumed = unitsConsumed;
        this.TotalAmount = TotalAmount;
    }

    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    public Double getTotalAmount() {
        return TotalAmount;
    }

    public void setTotalAmount(Double totalAmount) {
        TotalAmount = totalAmount;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Integer getUnitsConsumed() {
        return unitsConsumed;
    }

    public void setUnitsConsumed(Integer unitsConsumed) {
        this.unitsConsumed = unitsConsumed;
    }


}





