package com.gurjeet1.loginregister.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;

import com.gurjeet1.loginregister.R;
import com.gurjeet1.loginregister.model.Sandwich;

import java.io.Serializable;

public class MenuActivity extends AppCompatActivity implements Serializable {
    private ImageButton imgbmt;
    private ImageButton imgblt;
    private ImageButton imgroastbeef;
    private ImageButton imgveggie;
    private ImageButton imgtuna;
    private ImageButton imgsubwayclub;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
       imgbmt =(ImageButton) findViewById(R.id.imgbmt);
       imgblt = (ImageButton)findViewById(R.id.imgblt);
       imgroastbeef=(ImageButton)findViewById(R.id.imgroastbeef);
       imgsubwayclub=(ImageButton)findViewById(R.id.imgsubwayclub);
       imgtuna =(ImageButton)findViewById(R.id.imgtuna);
       imgveggie =(ImageButton)findViewById(R.id.imgveggie);
       final Sandwich sandwich = new Sandwich();
       imgbmt.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {

               sandwich.setSandwichtype("BMT");
               sandwich.setPrice(9.00);
               Intent mIntent = new Intent(MenuActivity.this, BreadSelectActivity.class);
               mIntent.putExtra("sandwich", sandwich);

               Log.d("value",sandwich.getSandwichtype());
               Log.d("value",sandwich.getPrice().toString());

               startActivity(mIntent);
               finish();

           }
       });


       imgblt.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               sandwich.setSandwichtype("BLT");
               sandwich.setPrice(7.99);
               Intent mIntent = new Intent(MenuActivity.this, BreadSelectActivity.class);
               mIntent.putExtra("sandwich", sandwich);
               Log.d("value",sandwich.getSandwichtype());
               Log.d("value",sandwich.getPrice().toString());

               startActivity(mIntent);
               finish();
           }
       });

        imgroastbeef.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sandwich.setSandwichtype("Roast Beef");
                sandwich.setPrice(7.99);
                Intent mIntent = new Intent(MenuActivity.this, BreadSelectActivity.class);
                mIntent.putExtra("sandwich", sandwich);
                startActivity(mIntent);
                finish();
            }
        });
        imgtuna.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sandwich.setSandwichtype("Tuna");
                sandwich.setPrice(7.99);
                Intent mIntent = new Intent(MenuActivity.this, BreadSelectActivity.class);
                mIntent.putExtra("sandwich", sandwich);
                startActivity(mIntent);
                finish();
            }
        });

        imgveggie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sandwich.setSandwichtype("Veggie");
                sandwich.setPrice(6.99);
                Intent mIntent = new Intent(MenuActivity.this, BreadSelectActivity.class);
                mIntent.putExtra("sandwich", sandwich);
                startActivity(mIntent);
                finish();
            }
        });

        imgsubwayclub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sandwich.setSandwichtype("Subway Club");
                sandwich.setPrice(7.99);
                Intent mIntent = new Intent(MenuActivity.this, BreadSelectActivity.class);
                mIntent.putExtra("sandwich", sandwich);
                startActivity(mIntent);
                finish();
            }
        });




       }

}
