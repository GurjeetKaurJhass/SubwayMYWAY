package com.gurjeet1.loginregister.adapters;

import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.gurjeet1.loginregister.R;
import com.gurjeet1.loginregister.model.Sandwich;

import java.util.List;

public class OrderRecyclerAdapter extends RecyclerView.Adapter<OrderRecyclerAdapter.OrderViewHolder> {
    private List<Sandwich> listOrder;

    public OrderRecyclerAdapter(List<Sandwich> listOrder) {
        this.listOrder = listOrder;
    }




    @Override
    public OrderViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        // inflating recycler item view
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_order_recycler, parent, false);

        return new OrderViewHolder(itemView);

    }

    @Override
    public void onBindViewHolder(OrderViewHolder holder, int position) {

//   holder.txtOrderId.setText(listOrder.get(position).get());
//   holder.txtUserId.setText(listOrder.get(position).getUserID);
//   holder.txtDate.setText(listOrder.get(position).getOrder_date());
   holder.txtSandwichType.setText(listOrder.get(position).getSandwichtype());
   holder.txtIngredients.setText(listOrder.get(position).getIngredients());
   holder.txtextaCheese.setText(String.valueOf(listOrder.get(position).getExtracheese()));
   holder.txtextraMeat.setText(String.valueOf(listOrder.get(position).getExtrameat()));
   holder.txtTotal.setText(String.valueOf(listOrder.get(position).getPrice()));

    }

    @Override
    public int getItemCount() {


        Log.v(UsersRecyclerAdapter.class.getSimpleName(),""+listOrder.size());
        return listOrder.size();

    }

    public class OrderViewHolder extends RecyclerView.ViewHolder {

        public AppCompatTextView txtOrderId;
        public AppCompatTextView txtUserId;
        public AppCompatTextView txtDate;
        public AppCompatTextView txtSandwichType;
        public AppCompatTextView txtIngredients;

        public AppCompatTextView txtextaCheese;
        public AppCompatTextView txtextraMeat;
        public AppCompatTextView txtTotal;


        public OrderViewHolder(View view) {
            super(view);
            txtOrderId = (AppCompatTextView) view.findViewById(R.id.txtViewId);
            txtUserId = (AppCompatTextView) view.findViewById(R.id.txtViewUserId);
            txtDate = (AppCompatTextView) view.findViewById(R.id.txtViewDate);
            txtSandwichType = (AppCompatTextView) view.findViewById(R.id.txtSandwichtype);
            txtextaCheese = (AppCompatTextView) view.findViewById(R.id.txtExtraCheese);
            txtextraMeat = (AppCompatTextView) view.findViewById(R.id.txtExtraMeat);
            txtTotal = (AppCompatTextView) view.findViewById(R.id.txtTotalPrice);


        }
    }

}
