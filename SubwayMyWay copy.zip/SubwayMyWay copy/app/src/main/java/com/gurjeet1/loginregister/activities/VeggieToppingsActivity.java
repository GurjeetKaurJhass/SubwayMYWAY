package com.gurjeet1.loginregister.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioGroup;

import com.gurjeet1.loginregister.R;
import com.gurjeet1.loginregister.model.Sandwich;

public class VeggieToppingsActivity extends AppCompatActivity {
private Button btnadd;
private CheckBox chkOnion;
private CheckBox chktomatoes;
private CheckBox chkGreenpepper;
private CheckBox chkOlives;
    private CheckBox chkketchup;
    private CheckBox chkmayonese;
    private CheckBox chkranch;
   Sandwich sandwich;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_veggie_toppings);


        final Intent mIntent = getIntent();
        Bundle mBundle = mIntent.getExtras();
        sandwich = (Sandwich) mBundle.getSerializable("sandwich");

        chkOnion=(CheckBox) findViewById(R.id.chkonions);
        chktomatoes=(CheckBox) findViewById(R.id.chktomatoes);
        chkGreenpepper=(CheckBox) findViewById(R.id.chkgreenpepper);
        chkOlives=(CheckBox) findViewById(R.id.chkolives);
        chkketchup=(CheckBox) findViewById(R.id.chkketchup);
        chkmayonese=(CheckBox) findViewById(R.id.chkmayonese);
        chkranch=(CheckBox) findViewById(R.id.chkranch);
        btnadd=(Button)findViewById(R.id.btnadd);
        Log.d("valueon veg",sandwich.getBreadtype());
//
        Log.d("value on veg",sandwich.getSize().toString());



    btnadd.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String ingredients=" ";
            if(chkOnion.isChecked())
            {
                ingredients+= "Onions ";
                sandwich.setIngredients(ingredients);
            }
            if(chktomatoes.isChecked())
            {
                ingredients+= "Tomatoes ";
                sandwich.setIngredients(ingredients);
            }

            if(chkGreenpepper.isChecked())
            {
                ingredients+= "GreenPepper ";
                sandwich.setIngredients(ingredients);
            }

            if(chkOlives.isChecked())
            {
                ingredients+= "Olives ";
                sandwich.setIngredients(ingredients);
            }

            if(chkketchup.isChecked())
            {
                ingredients+= "Ketchup ";
                sandwich.setIngredients(ingredients);
            }

            if(chkmayonese.isChecked())
            {
                ingredients+= "Mayonese ";
                sandwich.setIngredients(ingredients);

            }
            if(chkranch.isChecked())
            {
                ingredients+= "Ranch ";
                sandwich.setIngredients(ingredients);
            }



            Intent mIntent = new Intent(VeggieToppingsActivity.this, ExtraActivity.class);
            mIntent.putExtra("sandwich", sandwich);

            Log.d("value11111",sandwich.getIngredients());

            startActivity(mIntent);
            finish();

        }
    });

}


}
