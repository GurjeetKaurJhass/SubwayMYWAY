package com.gurjeet1.loginregister.sql;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.gurjeet1.loginregister.model.Sandwich;
import com.gurjeet1.loginregister.model.User;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "UserManager.db";

    // User table name
    private static final String TABLE_USER = "user";
    private static final String TABLE_ORDER = "orders";

    // User Table Columns names
    private static final String COLUMN_USER_ID = "user_id";
    private static final String COLUMN_USER_NAME = "user_name";
    private static final String COLUMN_USER_EMAIL = "user_email";
    private static final String COLUMN_USER_PASSWORD = "user_password";

    // ORDER Table Columns names
    private static final String COLUMN_ORDER_ID = "order_id";
    private static final String COLUMN_ORDER_DATE = "order_date";
    private static final String COLUMN_SANDWICH_TYPE = "sandwich_type";
    private static final String COLUMN_INGREDIANTS = "ingredients";
    private static final String COLUMN_EXTRA_CHEESE = "extra_cheese";
    private static final String COLUMN_EXTRA_MEAT = "extra_meat";
    private static final String COLUMN_TOTALPRICE = "totalPrice";




    // create table sql query
    private String CREATE_USER_TABLE = "CREATE TABLE " + TABLE_USER + "("
            + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + COLUMN_USER_NAME + " TEXT,"
            + COLUMN_USER_EMAIL + " TEXT," + COLUMN_USER_PASSWORD + " TEXT" + ")";


    // create table sql query
    private String CREATE_ORDER_TABLE = "CREATE TABLE "  + TABLE_ORDER + "("
            + COLUMN_ORDER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + COLUMN_USER_ID + " INTEGER ,"+ COLUMN_ORDER_DATE + " TEXT,"
            + COLUMN_SANDWICH_TYPE + " TEXT," + COLUMN_INGREDIANTS + " TEXT," + COLUMN_EXTRA_CHEESE +" TEXT," + COLUMN_EXTRA_MEAT + " TEXT," + COLUMN_TOTALPRICE + " TEXT" + ")";


    // drop table sql query
    private String DROP_USER_TABLE = "DROP TABLE IF EXISTS " + TABLE_USER;

    private String DROP_ORDER_TABLE = "DROP TABLE IF EXISTS " + TABLE_ORDER;



    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USER_TABLE);
        db.execSQL(CREATE_ORDER_TABLE);
    }




    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        //Drop User Table if exist
        db.execSQL(DROP_USER_TABLE);
        db.execSQL(DROP_ORDER_TABLE);

        // Create tables again
        onCreate(db);

    }

    /**
     * This method is to create user record
     *
     * @param user
     */
    public void addUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_NAME, user.getName());
        values.put(COLUMN_USER_EMAIL, user.getEmail());
        values.put(COLUMN_USER_PASSWORD, user.getPassword());

        // Inserting Row
        db.insert(TABLE_USER, null, values);
        db.close();
    }


    public void addOrder(Sandwich sandwich1) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues orderVal = new ContentValues();

//        //orderVal.put(COLUMN_USER_ID, );
//        orderVal.put(COLUMN_ORDER_DATE, );
        orderVal.put(COLUMN_SANDWICH_TYPE, sandwich1.getSandwichtype());
        orderVal.put(COLUMN_INGREDIANTS, sandwich1.getIngredients());
        orderVal.put(COLUMN_EXTRA_CHEESE, sandwich1.getExtracheese());
        orderVal.put(COLUMN_EXTRA_MEAT, sandwich1.getExtrameat());
        orderVal.put(COLUMN_TOTALPRICE,sandwich1.getPrice());

        // Inserting Row
        db.insert(TABLE_ORDER, null, orderVal);
        db.close();
    }










    public List<User> getAllUser() {
        // array of columns to fetch
        String[] columns = {
                COLUMN_USER_ID,
                COLUMN_USER_EMAIL,
                COLUMN_USER_NAME,
                COLUMN_USER_PASSWORD
        };
        // sorting orders
        String sortOrder =
                COLUMN_USER_NAME + " ASC";
        List<User> userList = new ArrayList<User>();

        SQLiteDatabase db = this.getReadableDatabase();




        Cursor cursor = db.query(TABLE_USER, //Table to query
                columns,    //columns to return
                null,        //columns for the WHERE clause
                null,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                sortOrder); //The sort order


        // Traversing through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                User user = new User();
                user.setId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(COLUMN_USER_ID))));
                user.setName(cursor.getString(cursor.getColumnIndex(COLUMN_USER_NAME)));
                user.setEmail(cursor.getString(cursor.getColumnIndex(COLUMN_USER_EMAIL)));
                user.setPassword(cursor.getString(cursor.getColumnIndex(COLUMN_USER_PASSWORD)));
                // Adding user record to list
                userList.add(user);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();

        // return user list
        return userList;
    }



    public List<Sandwich>getAllOrders() {
        // array of columns to fetch
        String[] columns = {
                COLUMN_ORDER_ID,
                COLUMN_USER_ID,
                COLUMN_ORDER_DATE,
                COLUMN_SANDWICH_TYPE,
                COLUMN_INGREDIANTS,
                COLUMN_EXTRA_CHEESE,
                COLUMN_EXTRA_MEAT,
                COLUMN_TOTALPRICE
        };
        // sorting orders
   String sortOrder =
                COLUMN_ORDER_ID + " ASC";
        List<Sandwich> orderList = new ArrayList<Sandwich>();

        SQLiteDatabase db = this.getReadableDatabase();



        Cursor cursor = db.query(TABLE_ORDER, //Table to query
                columns,    //columns to return
                null,        //columns for the WHERE clause
                null,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                sortOrder); //The sort order


        // Traversing through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
               Sandwich sandwich = new Sandwich();
//                sandwich.setorder_id(Integer.parseInt(cursor.getString(cursor.getColumnIndex(COLUMN_ORDER_ID))));
//               // order.setUser_id(cursor.getString(cursor.getColumnIndex(COLUMN_USER_ID)));
//                sandwich.setOrder_date(cursor.getString(cursor.getColumnIndex(COLUMN_ORDER_DATE)));
                sandwich.setSandwichtype(cursor.getString(cursor.getColumnIndex(COLUMN_SANDWICH_TYPE)));
                sandwich.setIngredients(cursor.getString(cursor.getColumnIndex(COLUMN_INGREDIANTS)));
                sandwich.setExtracheese(cursor.getDouble(cursor.getColumnIndex(COLUMN_EXTRA_CHEESE)));
                sandwich.setExtra_cheese(cursor.getDouble(cursor.getColumnIndex(COLUMN_EXTRA_MEAT)));
                sandwich.setTotalPrice(cursor.getString(cursor.getColumnIndex(COLUMN_TOTALPRICE)));

                // Adding order record to list
                orderList.add(sandwich);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();


        return orderList;
    }



    public void updateUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_NAME, user.getName());
        values.put(COLUMN_USER_EMAIL, user.getEmail());
        values.put(COLUMN_USER_PASSWORD, user.getPassword());

        // updating row
        db.update(TABLE_USER, values, COLUMN_USER_ID + " = ?",
                new String[]{String.valueOf(user.getId())});
        db.close();
    }




    public void deleteUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        // delete user record by id
        db.delete(TABLE_USER, COLUMN_USER_ID + " = ?",
                new String[]{String.valueOf(user.getId())});
        db.close();
    }




    public boolean checkUser(String email) {

        // array of columns to fetch
        String[] columns = {
                COLUMN_USER_ID
        };
        SQLiteDatabase db = this.getReadableDatabase();

        // selection criteria
        String selection = COLUMN_USER_EMAIL + " = ?";

        // selection argument
        String[] selectionArgs = {email};


        Cursor cursor = db.query(TABLE_USER, //Table to query
                columns,                    //columns to return
                selection,                  //columns for the WHERE clause
                selectionArgs,              //The values for the WHERE clause
                null,                       //group the rows
                null,                      //filter by row groups
                null);                      //The sort order
        int cursorCount = cursor.getCount();
        cursor.close();
        db.close();

        if (cursorCount > 0) {
            return true;
        }

        return false;
    }


    public boolean checkUser(String email, String password) {

        // array of columns to fetch
        String[] columns = {
                COLUMN_USER_ID
        };
        SQLiteDatabase db = this.getReadableDatabase();
        // selection criteria
        String selection = COLUMN_USER_EMAIL + " = ?" + " AND " + COLUMN_USER_PASSWORD + " = ?";

        // selection arguments
        String[] selectionArgs = {email, password};


        Cursor cursor = db.query(TABLE_USER, //Table to query
                columns,                    //columns to return
                selection,                  //columns for the WHERE clause
                selectionArgs,              //The values for the WHERE clause
                null,                       //group the rows
                null,                       //filter by row groups
                null);                      //The sort order

        int cursorCount = cursor.getCount();

        cursor.close();
        db.close();
        if (cursorCount > 0) {
            return true;
        }

        return false;
    }
}
